#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;

#define FF first
#define SS second
#define mp make_pair

ll delta;
ll n = (ll)(1e18)+2;

ll bpow(ll a, ll b, ll mod = delta)
{
	ll res = 1;
	while (b)
	{
		if (b & 1)
			res = res * a % mod;
		a = a * a % mod;
		b >>= 1;
	}
	return res;
}

int main(int argc, char *argv[])
{
	ios::sync_with_stdio(false);
	
	delta = atoi(argv[1]);
	ll dd = delta - 1;

	ll cnt = n / 2;
	ll ans = 0, pw = 0;
	if (cnt % 2 == 0)
	{
		ans = cnt / 2 % delta * ((cnt - 1) % delta) % delta;
		pw = cnt / 2 % dd * ((cnt - 1) % dd) % dd;	
	}
	else
	{
		ans = (cnt - 1) / 2 % delta * (cnt % delta) % delta;
		pw = (cnt - 1) / 2 % dd * (cnt % dd) % dd;	
	}
	if (n % 2 == 1)
	{
		ans += cnt, ans %= delta;
		pw += cnt, pw %= dd;
	}
	cout << bpow(ans, pw) << "\n";
	return 0;
}
