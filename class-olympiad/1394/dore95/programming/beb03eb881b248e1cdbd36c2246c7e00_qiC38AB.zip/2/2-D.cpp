#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;

#define FF first
#define SS second
#define mp make_pair

ll delta;
const ll n = 1e3 + 2;
ll M = 100000000019;
ll a[n+100], b[n+100];
ll ans[n+100][n+100];

ll bpow(ll a, ll b, ll mod = delta)
{
	ll res = 1;
	while (b)
	{
		if (b & 1)
			res = res * a % mod;
		a = a * a % mod;
		b >>= 1;
	}
	return res;
}

int main(int argc, char *argv[])
{
	ios::sync_with_stdio(false);

	delta = atoi(argv[1]);
	ll dd = delta - 1;

	a[0] = 2016 % M;
	for (int i=1; i<n; i++)
		a[i] = (a[i-1] * 1437 % M + 1395) % M;


	for (int r=n; r>0; r--)
	{
		for (int i=0; i<r; i++)
			b[i] = a[i];
		for (int i=r-1; i>0; i--)
		{
			ll sum = b[i];
			for (int j=i-1; j>=0; j--)
			{
				sum += b[j];
				ll each = (sum + i - j) / (i-j+1);
				if (each > b[i])
				{
					ll mv = each - b[i];
					b[j] -= mv;
					b[i] += mv;
					ans[r][j] += mv * (i - j);
				}
			}
		}
		for (int i=r-1; i>0; i--)
			ans[r][i-1] += ans[r][i];
	}
	ll all = 0;
	for (int r=1; r<=n; r++)
		for (int l=0; l<n; l++)
			all += ans[r][l], all %= delta;
	cout << all << "\n";
	return 0;
}
