#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;

#define FF first
#define SS second
#define mp make_pair

ll delta;
const ll n = 1e4 + 2;
ll M = 100000000019;
ll a[n+100], b[n+100];
ll ans[n+100];
stack<pair<ll, ll> > st;
const ll INF = 1e13 + 7;

ll bpow(ll a, ll b, ll mod = delta)
{
	ll res = 1;
	while (b)
	{
		if (b & 1)
			res = res * a % mod;
		a = a * a % mod;
		b >>= 1;
	}
	return res;
}

ll sum(ll l, ll r)
{
	return (r - l + 1) * (r + l) / 2;
}

int main(int argc, char *argv[])
{
	ios::sync_with_stdio(false);

	delta = atoi(argv[1]);
	ll dd = delta - 1;

	a[0] = 2016 % M;
	for (int i=1; i<n; i++)
		a[i] = (a[i-1] * 1437 % M + 1395) % M;

	ll all = 0;
	for (int r=n; r>0; r--)
	{
	
		for (int i=0; i<r; i++)
			b[i] = a[i], ans[i] = 0;

		while (!st.empty()) st.pop();
		st.push({r, INF});

		for (int i=r-1; i>=0; i--)
		{
			ll h = 0;
			while ((st.top().first-i) * (st.top().second-h) <= b[i] - h)
			{
				ll cnt = (st.top().first-i) * (st.top().second-h);
				ans[i] += sum(0, st.top().first-i-1) * (st.top().second-h);
				b[i] -= cnt - (st.top().second-h);
				h = st.top().second;
				st.pop();
			}
			ll cnt = b[i] - h;
			ll all = cnt / (st.top().first-i);
			ll rm = cnt % (st.top().first-i);
			ans[i] += all * sum(0, st.top().first-i-1);
			ans[i] += sum(st.top().first-rm-i, st.top().first-1-i);
			st.push({st.top().first-rm, h + all + 1});
			st.push({i, h + all});
		}

		for (int i=r-1; i>0; i--)
			ans[i-1] += ans[i];
		for (int l=0; l<r; l++)
			all += ans[l], all %= delta;
	}
	cout << all << "\n";
	return 0;
}
