#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;

#define FF first
#define SS second
#define mp make_pair

ll delta;
const ll n = 1e3+2;
ll M = 1e11+19;
ll a[n];

ll bpow(ll a, ll b, ll mod = delta)
{
	ll res = 1;
	a %= mod;
	while (b)
	{
		if (b & 1) 
			res = res * a % mod;
		a = a * a % mod;
		b >>= 1;
	}
	return res;
}

int main(int argc, char *argv[])
{
	ios::sync_with_stdio(false);

	delta = atoi(argv[1]);
	ll dd = delta - 1;

	a[0] = 2016 % M;
	for (int i=1; i<n; i++)
		a[i] = (a[i-1] * 1437 % M + 1395) % M;
	ll ans = 0;
	for (int i=n-1; i>0; i--)
	{
		ll sum = a[i];
		for (int j=i-1; j>=0; j--)
		{
			sum += a[j];
			ll each = (sum + i - j) / (i-j+1);
			if (each > a[i])
			{
				ll mv = each - a[i];
				a[j] -= mv;
				a[i] += mv;
				ans += mv * (i - j);
			}
		}
	}
	cout << bpow(ans, ans) << "\n";
	return 0;
}
