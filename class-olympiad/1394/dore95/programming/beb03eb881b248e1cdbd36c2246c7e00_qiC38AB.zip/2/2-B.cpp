#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;

#define FF first
#define SS second
#define mp make_pair

ll delta;
const ll n = 1e3+2;
ll M = 123457;
ll a[n];

ll bpow(ll a, ll b, ll mod = delta)
{
	ll res = 1;
	while (b)
	{
		if (b & 1)
			res = res * a % mod;
		a = a * a % mod;
		b >>= 1;
	}
	return res;
}

int main(int argc, char *argv[])
{
	ios::sync_with_stdio(false);

	delta = atoi(argv[1]);
	ll dd = delta - 1;

	a[0] = 2016 % M;
	for (int i=1; i<n; i++)
		a[i] = (a[i-1] * 1437 % M + 1395) % M;
	int ans = 0;
	for (int i=n-2; i>=0; i--)
	{
		while (a[i] > a[i+1])
		{
			int p = i;
			while (p+1 < n && a[p] > a[p+1])
			{
				a[p]--, a[++p]++, ans++;
			}
		}
	}
	cout << bpow(ans, ans) << "\n";
	return 0;
}
