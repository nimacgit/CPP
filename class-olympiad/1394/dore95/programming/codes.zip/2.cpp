#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
#define Foreach(i, c) for(__typeof((c).begin()) i = (c).begin(); i != (c).end(); ++i)
#define For(i,a,b) for(int (i)=(a);(i) < (b); ++(i))
#define rof(i,a,b) for(int (i)=(a);(i) > (b); --(i))
#define rep(i, c) for(auto &(i) : (c))
#define x first
#define y second
#define pb push_back
#define PB pop_back()
#define iOS ios_base::sync_with_stdio(false)
#define sqr(a) (((a) * (a)))
#define all(a) a.begin() , a.end()
#define error(x) cerr << #x << " = " << (x) <<endl
#define Error(a,b) cerr<<"( "<<#a<<" , "<<#b<<" ) = ( "<<(a)<<" , "<<(b)<<" )\n";
#define errop(a) cerr<<#a<<" = ( "<<((a).x)<<" , "<<((a).y)<<" )\n";
#define coud(a,b) cout<<fixed << setprecision((b)) << (a)
#define L(x) ((x)<<1)
#define R(x) (((x)<<1)+1)
#define umap unordered_map
#define double long double
typedef long long ll;
typedef pair<int, int>pii;
typedef vector<int> vi;
typedef complex<double> point;
template <typename T> using os =  tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template <class T>  inline void smax(T &x,T y){ x = max((x), (y));}
template <class T>  inline void smin(T &x,T y){ x = min((x), (y));}
const int maxn = 1234567 + 100;
ll d[maxn][60][2];
ll dp[maxn][60];
ll mod;
const ll inf = 1LL << 60;
vector<pii> vec[maxn];
int a[maxn];
vi v;
inline ll mn(){
	int n = v.size();
	v.pb(0);
	reverse(all(v));
	For(i,0,v.size() + 2)
		For(j,0,30)	For(k,0,2)
			d[i][j][k] = inf;
	d[0][0][1] = 0;
	d[0][0][0] = 0;
	For(i,1,n+1){
		int x = v[i];
		For(j,0,v[i-1] + 1){
			int hm = min(x, j);
			For(k,0,hm+1){
				int b = j - k;
				int a = x - k;
				if(!b){
					smin(d[i][a][1], min(d[i-1][j][1], d[i-1][j][0]) + (ll)k);
					smin(d[i][a][0], min(d[i-1][j][1], d[i-1][j][0]) + (ll)k);
				}
				else
					smin(d[i][a][0], d[i-1][j][1] + (ll)k);
			}
		}
	}
	ll ans = d[n][0][0];
	For(i,0,30)
		smin(ans, d[n][i][1]);
	return ans;
}
typedef pair<ll, ll> pll;
inline ll cntw(){
	int n = v.size() - 1;
	For(i,0,v.size() + 2)
		For(j,0,30)	dp[i][j] = 0LL;
	dp[0][0] = 1LL;
	For(i,1,n+1){
		int x = v[i];
		For(j,0,v[i-1] + 1){
			int hm = min(x, j);
			For(k,0,hm+1){
				int b = j - k;
				int a = x - k;
				dp[i][a] = (1LL * dp[i][a] + dp[i-1][j]) % mod;
			}
		}
	}
	ll ans = 0LL;
	For(i,0,30)
		ans = (ans + dp[n][i]) % mod;
	return ans;
}
inline pll solve(int n, int M){
	For(i,0,maxn)
		vec[i].clear();
	a[0] = 1426;
	For(i,1,n)
		a[i] = 1 + (1394LL * a[i-1] + 2015LL)%M;
	For(i,0,n){
		int x = a[i];
		for(int p = 2;p * p <= x;p ++)if(x % p == 0){
			int cnt = 0;
			while(x % p == 0){
				cnt ++;
				x /= p;
			}
			vec[p].pb({i, cnt});
		}
		if(x > 1)
			vec[x].pb({i, 1});
	}
	ll cnt = 1LL;
	ll ans = 0LL;
	For(i,1,M + 1)if(!vec[i].empty()){
		v.clear();
		vec[i].pb({n+10, 0});
		For(j,0,vec[i].size()){
			if(!v.empty() && j && vec[i][j].x != vec[i][j-1].x + 1){
				ans = (1LL * ans + mn()) % mod;
				cnt = (1LL * cnt * cntw())% mod;
				v.clear();
			}
			v.pb(vec[i][j].y);
		}
	}
	return {ans, cnt};
}
int main(){
	iOS;
	cin >> mod;	// reading your delta
	cout << solve(7890, 7901).y << endl;
	pll p = solve(1234567, 1234577);
	cout << p.y << endl << p.x << endl;
}
