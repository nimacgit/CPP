#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
#define Foreach(i, c) for(__typeof((c).begin()) i = (c).begin(); i != (c).end(); ++i)
#define For(i,a,b) for(int (i)=(a);(i) < (b); ++(i))
#define rof(i,a,b) for(int (i)=(a);(i) > (b); --(i))
#define rep(i, c) for(auto &(i) : (c))
#define x first
#define y second
#define pb push_back
#define PB pop_back()
#define iOS ios_base::sync_with_stdio(false)
#define sqr(a) (((a) * (a)))
#define all(a) a.begin() , a.end()
#define error(x) cerr << #x << " = " << (x) <<endl
#define Error(a,b) cerr<<"( "<<#a<<" , "<<#b<<" ) = ( "<<(a)<<" , "<<(b)<<" )\n";
#define errop(a) cerr<<#a<<" = ( "<<((a).x)<<" , "<<((a).y)<<" )\n";
#define coud(a,b) cout<<fixed << setprecision((b)) << (a)
#define L(x) ((x)<<1)
#define R(x) (((x)<<1)+1)
#define umap unordered_map
#define double long double
typedef long long ll;
typedef pair<int, int>pii;
typedef vector<int> vi;
typedef complex<double> point;
template <typename T> using os =  tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template <class T>  inline void smax(T &x,T y){ x = max((x), (y));}
template <class T>  inline void smin(T &x,T y){ x = min((x), (y));}
const int maxn = 12345678 + 100;
int mod;
inline int power(int a,int b){
	if(!b)	return 1;
	int c = power(a, b/2);
	c = (1LL * c * c) % mod;
	if(b % 2)
		c = (1LL * c * a) % mod;
	return c;
}
int fact[maxn], t[maxn], d[maxn];
inline int c(int n, int r){
	int ans = fact[n];
	ans = (1LL * ans * power(fact[r], mod - 2)) % mod;
	ans = (1LL * ans * power(fact[n-r], mod - 2)) % mod;
	return ans;
}
inline int c(int n){
	ll ans = (1LL * n * (n-1LL));
	ans /= 2LL;
	ans %= mod;
	return ans;
}
inline int solve(int n){
	fill(d,d+n+3,0);
	fact[0] = 1;
	For(i,1,n + 3)
		fact[i] = (1LL * i * fact[i-1]) % mod;
	For(i,0,n+1)
		t[i] = c(n, i);
	int ans = 0;
	rof(i,n,0){
		int x = 0;
		for(int j = i;j <= n;j += i){
			x = (x + t[j]) % mod;
			d[i] = (1LL * d[i] + 1LL * mod - 1LL * d[j]) % mod;
		}
		x = c(x);
		d[i] = (1LL * d[i] + x) % mod;
		x = (1LL * i * d[i]) % mod;
		ans = (ans + x) % mod;
	}
	return ans;
}
int main(){
	iOS;
	cin >> mod;	// reading your delta
	int delta = mod;
	cout << solve(14) << endl;
	cout << solve(1234) << endl;
	mod = 1e9 + 7;
	cout << solve(12345678) % delta << endl;
}
