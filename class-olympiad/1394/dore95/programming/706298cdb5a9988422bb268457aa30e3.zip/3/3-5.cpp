#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll MOD,n;
ll pw(ll a,ll b=MOD-2){return b?pw(a*a%MOD,b>>1)*(b&1?a:1)%MOD:1;}
ll f(ll n){return n&1?(pw(4,n/2+1)+2)%MOD*pw(6)%MOD:(pw(4,n/2)-1+MOD)%MOD*pw(3)%MOD;}
int main(int argc,char *argv[])
{
	MOD=atoi(argv[1]);
	cout<<(f(1e6)+f(1e6-9))%MOD<<endl;
}
